const questions = [
  {
    question: "What does HTML stand for?",
    answer: "HyperText Markup Language"
  },
  {
    question: "What language styles a webpage?",
    answer: "CSS"
  },
  {
    question: "Which language makes websites interactive?",
    answer: "JavaScript"
  }
];

let currentIndex = 0;

const questionContainer = document.getElementById("question-container");
const nextBtn = document.getElementById("next-btn");

function showQuestion() {
  if (currentIndex < questions.length) {
    questionContainer.innerHTML = `
      <p>${questions[currentIndex].question}</p>
      <input id="user-answer" placeholder="Your answer">
    `;
  } else {
    questionContainer.innerHTML = `<p>Quiz Completed!</p>`;
    nextBtn.style.display = "none";
  }
}

nextBtn.addEventListener("click", () => {
  const userAnswer = document.getElementById("user-answer").value.trim();
  if (userAnswer.toLowerCase() === questions[currentIndex].answer.toLowerCase()) {
    alert("Correct!");
  } else {
    alert(\`Wrong! The correct answer is: \${questions[currentIndex].answer}\`);
  }
  currentIndex++;
  showQuestion();
});

showQuestion();
